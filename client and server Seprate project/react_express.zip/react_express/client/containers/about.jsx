import React, { Component } from 'react';
import { render } from 'react-dom';
import {Router,hashHistory,Route} from 'react-router';

class About extends React.Component {
   render() {
      return (
         <div>
            <h1>About...</h1>
         </div>
      )
   }
}

export default About;